package com.example.skip.enumeration;

public enum UserRole {
    USER, MANAGER, ADMIN
}
