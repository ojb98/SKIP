package com.example.skip.repository;

import com.example.skip.entity.RefundsHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RefundsHistoryRepository extends JpaRepository<RefundsHistory,Long> {
}
