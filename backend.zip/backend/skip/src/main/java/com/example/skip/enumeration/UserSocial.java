package com.example.skip.enumeration;

public enum UserSocial {
    NONE, KAKAO, NAVER
}
