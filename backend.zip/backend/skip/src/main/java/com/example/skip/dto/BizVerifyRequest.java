package com.example.skip.dto;

import lombok.Data;

@Data
public class BizVerifyRequest {
    private String bizRegNumber;
}