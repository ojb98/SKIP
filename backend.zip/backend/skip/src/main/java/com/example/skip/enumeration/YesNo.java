package com.example.skip.enumeration;

public enum YesNo {
    Y,N
}
