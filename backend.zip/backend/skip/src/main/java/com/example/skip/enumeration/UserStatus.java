package com.example.skip.enumeration;

public enum UserStatus {
    PENDING, APPROVED, WITHDRAWN
}
